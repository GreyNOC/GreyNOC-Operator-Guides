================================================================================
 GREYNOC -- WAR-DRIVING OPERATOR PROGRAM
 Zero-to-Hero Curriculum for Authorized Android-Linux Wireless Reconnaissance
================================================================================
 greynoc.com  |  Certified Penetration Testing & Ethical Hacking  |  Michigan
 Series: GreyNOC War-Driving Operator Program
 Template: GN-TPL-PUB-001   |   Classification: PUBLIC   |   Published 2026-06-14
--------------------------------------------------------------------------------

WHAT THIS IS
  A complete training pipeline that takes a new GreyNOC operator from zero to
  field-capable in authorized wireless reconnaissance ("war driving") using
  Android phones running a Linux toolchain. It is one Operator Setup guide plus
  ten class guides. Each class builds on the one before it.

  The program is DEFENSIVE. We use war driving to inventory our own wireless
  environment, detect rogue and unauthorized access points, find weak or
  misconfigured networks we are responsible for, and measure how far our signal
  leaks past the physical perimeter. We do NOT attack networks.

READ FIRST -- OPERATING LAWFULLY
  Every guide is for lawful, authorized, defensive use only. War driving is
  wireless reconnaissance: run it only against networks you own or are
  explicitly authorized IN WRITING to assess, within a signed scope and rules of
  engagement. Observe PASSIVELY -- collect broadcast metadata (SSID, BSSID,
  channel, signal, security), never the contents of anyone's traffic. Do not
  deauthenticate, jam, connect to, or interfere with networks you do not own;
  those acts are frequently illegal even in testing. Comply with all local,
  state, and federal law, and treat every dataset as confidential.

CONTENTS  (read in order; 80+ pages total)
  GreyNOC_WDR_00_Program_Index_v1.0.pdf .... Program index & syllabus (start here)
  GreyNOC_WDR_00_Operator_Setup_v1.0.pdf ... Class 0: Field readiness, device build, toolchain
  GreyNOC_WDR_01_Wireless_Fundamentals_v1.0.pdf .. Class 1: RF, 802.11 & the defensive mission
  GreyNOC_WDR_02_Recon_Platform_v1.0.pdf ... Class 2: Termux, PRoot & monitor-mode reality
  GreyNOC_WDR_03_Passive_Discovery_v1.0.pdf  Class 3: Capturing the wireless environment
  GreyNOC_WDR_04_GPS_Mapping_v1.0.pdf ...... Class 4: Geo-tagging & coverage mapping
  GreyNOC_WDR_05_Data_Provenance_v1.0.pdf .. Class 5: Reproducible, defensible datasets
  GreyNOC_WDR_06_Inventory_Baseline_v1.0.pdf Class 6: Known-good wireless asset management
  GreyNOC_WDR_07_Rogue_Detection_v1.0.pdf .. Class 7: Finding what should not be there
  GreyNOC_WDR_08_Perimeter_Leakage_v1.0.pdf  Class 8: Mapping coverage against the boundary
  GreyNOC_WDR_09_Analysis_Automation_v1.0.pdf Class 9: Turning captures into findings
  GreyNOC_WDR_10_Reporting_Operations_v1.0.pdf Class 10: Evidence, OPSEC & professional conduct

  Document IDs: GN-OPS-WDR-000 .. GN-OPS-WDR-010 (plus GN-OPS-WDR-IDX for the index).

DAY-ONE PATH
  1. Guide 0 (Operator Setup): build and verify a lawful field platform.
  2. Guides 1-3: enough to ride along and collect data the same day, supervised.
  3. Guides 4-5: make captures located and provenanced.
  4. Guides 6-7: the analytical core -- inventory, baseline, rogue detection.
  5. Guides 8-9: perimeter leakage and automation at scale.
  6. Guide 10: reporting, evidence, safety, and clean operations.

  New operators should pair with a senior operator for their first runs.

TECHNICAL NOTES
  - Monitor-mode capture is the program standard (Android API scans are OS-
    throttled). Two viable paths: a rooted phone with a Nexmon-supported
    Broadcom/Cypress chipset, OR an external USB Wi-Fi adapter over OTG run
    through a Linux chroot. Maintain a team-approved hardware list; monitor-mode
    support is fragile and device/version-dependent -- verify your exact combo.
  - Tools referenced: Termux/Termux:API, proot-distro / Kali NetHunter chroot,
    aircrack-ng suite (airmon-ng/airodump-ng), Kismet, gpsd, tshark, WiGLE
    formats, Python.

--------------------------------------------------------------------------------
 (c) 2026 GreyNOC. Public distribution permitted with attribution.
 For lawful, authorized, defensive and educational use only.
================================================================================
